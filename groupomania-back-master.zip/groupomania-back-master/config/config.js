module.exports = {
    development: {
        username: 'root',
        password: 'toor',
        database: 'database_development',
        host: '127.0.0.1',
        dialect: 'sqlite'
    },
    test: {
        username: 'root',
        password: 'toor',
        database: 'database_test',
        host: '127.0.0.1',
        dialect: 'sqlite'
    },
    production: {
        username: 'root',
        password: 'toor',
        database: 'database_production',
        host: '127.0.0.1',
        dialect: 'sqlite'
    }
};
